# crash-course-CRM
Django customer management platform
